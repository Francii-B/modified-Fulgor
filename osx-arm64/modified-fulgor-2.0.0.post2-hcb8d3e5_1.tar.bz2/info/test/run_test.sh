

set -ex



fulgor 2>&1 | grep -q "Usage: fulgor <tool> ..."
fulgor 2>&1 | grep -q "Tools:"
exit 0
