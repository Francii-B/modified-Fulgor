

set -ex



fulgor help
exit 0
